This is Coursework for GAN 
you can run by: python gan_tensorflow.py  to train this simple implementation of GAN
